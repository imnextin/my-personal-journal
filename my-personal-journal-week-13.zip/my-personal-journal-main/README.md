# my-personal-journal

Weekly Project Journal for the **First Order Motion Model for Image Animation**.

The journal documents the project from **Week 1 through Week 13**, covering:
- repository and environment setup
- Colab notebook interface
- image/video preprocessing
- model architecture and checkpoints
- inference and animation generation
- debugging
- model/configuration comparison
- output-quality analysis
- documentation
- final testing and project reflection
